import java.util.Random;

public class TestMyHashTable {
    public static void main(String[] args) {
        MyHashTable<MyTestingClass, String> table = new MyHashTable<>();
        Random random = new Random();
        for (int i = 0; i < 10000; i++) {
            int id = random.nextInt(100000);
            String name = "Name" + random.nextInt(100000);
            MyTestingClass key = new MyTestingClass(id, name);
            table.put(key, "Student" + i);
        }

        for (int i = 0; i < table.getChainArrayLength(); i++) {
            int count = 0;
            for (var node : table.getChainAt(i)) {
                count++;
            }
            System.out.println("Bucket " + i + ": " + count + " elements");
        }
    }
}