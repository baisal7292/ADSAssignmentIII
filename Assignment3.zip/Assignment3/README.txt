Assignment 3 - Hash Table and BST

Author: [Your Name]
Date: [Date]

Files:
- MyHashTable.java: Hash table with chaining
- MyTestingClass.java: Class with custom hashCode
- TestMyHashTable.java: Testing file for MyHashTable

Instructions:
1. Compile all Java files: javac *.java
2. Run TestMyHashTable to see hash table bucket distribution.